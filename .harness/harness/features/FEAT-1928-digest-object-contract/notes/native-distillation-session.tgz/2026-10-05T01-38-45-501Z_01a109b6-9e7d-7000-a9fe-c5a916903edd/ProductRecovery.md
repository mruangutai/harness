BLOCKED: Product reconciliation passed, but the native lead object cannot be accepted because Main omitted canonical run registration before dispatch. Recovery artifacts are complete at:

`.harness/harness/features/FEAT-1928-digest-object-contract/runs/distill-product-recovery-product/digest.md`

Main must register that grant-valid run and freshly dispatch ProductRecovery; this runtime cannot acquire a binding retroactively.